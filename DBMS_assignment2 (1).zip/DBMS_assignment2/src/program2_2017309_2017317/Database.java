package program2_2017309_2017317;

import java.io.Serializable;
import java.util.*;
public class Database implements Serializable{
	private boolean Lock;
	private int bookedflights;
	private ArrayList<Flight> Flist;
	private ArrayList<Passenger> Plist;
	
	public Database(){
		Lock=false;
		bookedflights=0;
		Flist=new ArrayList<Flight>();
		Plist=new ArrayList<Passenger>();
	}
	
	public int getBookedflights() {
		return bookedflights;
	}

	public void setBookedflights(int bookedflights) {
		this.bookedflights = bookedflights;
	}

	public void insertFlight(Flight F) {
		this.Flist.add(F);
	}
	
	public void insertPassenger(Passenger P) {
		this.Plist.add(P);
	}

	public boolean isLock() {
		return Lock;
	}

	public void setLock(boolean lock) {
		Lock = lock;
	}

	public ArrayList<Flight> getFlist() {
		return Flist;
	}

	public void setFlist(ArrayList<Flight> flist) {
		Flist = flist;
	}

	public ArrayList<Passenger> getPlist() {
		return Plist;
	}

	public void setPlist(ArrayList<Passenger> plist) {
		Plist = plist;
	}
	
	
	

}
