package program2_2017309_2017317;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.Math;
import java.lang.Thread;
import java.util.ArrayList;
public class Transaction implements Runnable {

	private int type;
	private int tid;
	private static int counter=1;
	
	Transaction(){
		this.tid=counter;
		counter++;
	}

	public static void serialize( Database DB) throws IOException{
		ObjectOutputStream out=null;
		try{
			out=new ObjectOutputStream(new FileOutputStream("Database.txt"));
			out.writeObject(DB);
		}finally{
			out.close();
		}
		
	}
	
	public static Database deserialize(Database DB) throws IOException, ClassNotFoundException{
		ObjectInputStream in=null;
		try{
			in=new ObjectInputStream(new FileInputStream("Database.txt"));
			DB=(Database)in.readObject();
		}finally{
			in.close();
		}
		
		return DB;
	}
	
	public static void serialize( CCM CurrState ) throws IOException{
		ObjectOutputStream out=null;
		try{
			out=new ObjectOutputStream(new FileOutputStream("CurrState.txt"));
			out.writeObject(CurrState);
		}finally{
			out.close();
		}
		
	}
	
	public static CCM deserialize(CCM Manager) throws IOException, ClassNotFoundException{
		ObjectInputStream in=null;
		try{
			in=new ObjectInputStream(new FileInputStream("Database.txt"));
			Manager=(CCM)in.readObject();
		}finally{
			in.close();
		}
		
		return Manager;
	}
	
	
	
	
	
	
	
	
//	Transaction (){
//	this.type=(int)(Math.random()*4)+1;
//	}
//	
//	public void reserve(String F, int i) throws InterruptedException {
//		if(CCM.getFdLock().equalsIgnoreCase("X") || CCM.getPdLock().equalsIgnoreCase("X")) {
//			this.wait();
//		}
//		if (CCM.getPdLock()==null && CCM.getFdLock()==null) {
//			CCM.lockXFlightDatabase();
//			CCM.lockXPassengerDatabase();
//		}
	private int Reserve(String F, String i) {
		
		Flight Ftemp=null;
		Passenger Ptemp=null;
		ArrayList<Flight> flist=CCM.DB.getFlist();
		ArrayList<Passenger> plist=CCM.DB.getPlist();
		int f=0,p=0;
		
		while(f<flist.size()-1) {
			Ftemp=flist.get(f);
			if(Ftemp.getId().equals(F)) {
				break;
			}
			f++;
		}
		
		while(p<plist.size()-1) {
			Ptemp=plist.get(p);
			if(Ptemp.getId().equals(i)) {
				break;
			}
			p++;
		}
		
		if( Ftemp.getFreeSeats()>0) {
		Ftemp.setFreeSeats(Ftemp.getFreeSeats()-1);
		Ftemp.setReservedSeats(Ftemp.getReservedSeats()+1);
		CCM.DB.setBookedflights(CCM.DB.getBookedflights()+1);
		Ftemp.getPassengerList().add(Ptemp);
		Ptemp.getReservedFlights().add(Ftemp);
		
		flist.set(f, Ftemp);
		plist.set(p,Ptemp);
		
		CCM.DB.setFlist(flist);
		CCM.DB.setPlist(plist);
		
		return 1;
		}
		else return 0;
	}
	
	public int Cancel(String F, String i) {
		
		Flight Ftemp=null;
		Passenger Ptemp=null;
		ArrayList<Flight> flist=CCM.DB.getFlist();
		ArrayList<Passenger> plist=CCM.DB.getPlist();
		int f=0,p=0;
		
		while(f<flist.size()-1) {
			Ftemp=flist.get(f);
			if(Ftemp.getId().equals(F)) {
				break;
			}
			f++;
		}
		
		while(p<plist.size()-1) {
			Ptemp=plist.get(p);
			if(Ptemp.getId().equals(i)) {
				break;
			}
			p++;
		}
		
		if(Ftemp.getPassengerList().indexOf(Ptemp)>=0) {
		
		
		Ftemp.setFreeSeats(Ftemp.getFreeSeats()+1);
		Ftemp.setReservedSeats(Ftemp.getReservedSeats()-1);
		CCM.DB.setBookedflights(CCM.DB.getBookedflights()-1);
		Ftemp.getPassengerList().remove(Ftemp.getPassengerList().indexOf(Ptemp));
		Ptemp.getReservedFlights().remove(Ptemp.getReservedFlights().indexOf(Ftemp));
		
		flist.set(f, Ftemp);
		plist.set(p,Ptemp);
		
		CCM.DB.setFlist(flist);
		CCM.DB.setPlist(plist);
		return 1;
		}
		
		else {
			return 0;
		}
		
	}
	
	public ArrayList<Flight> My_Flights(String id) {
		Passenger Ptemp=null;
		ArrayList<Passenger> plist=CCM.DB.getPlist();
		int p=0;
		while(p<plist.size()-1) {
			Ptemp=plist.get(p);
			if(Ptemp.getId().equals(id)) {
				break;
			}
			p++;
		}
		
		for(int j=0; j< Ptemp.getReservedFlights().size()-1; j++) {
			System.out.print(Ptemp.getReservedFlights().get(j)+" ");
		}
		System.out.println();
		return Ptemp.getReservedFlights();
		
	}
	
	public int Total_Reservations() {
		return CCM.DB.getBookedflights();
	}
	
	public int Transfer(String F1, String F2, String i) {
		
		int c=Cancel(F1,i);
		int r=Reserve(F2,i);
		
		if(c*r==1) {
			return 1;
		}
		
		else return 0;
		
		/*Flight Ftemp1=null,Ftemp2=null;
		Passenger Ptemp=null;
		ArrayList<Flight> flist=CCM.DB.getFlist();
		ArrayList<Passenger> plist=CCM.DB.getPlist();
		int f1=0,f2=0,p=0;
		
		while(f1<flist.size()-1) {
			Ftemp1=flist.get(f1);
			if(Ftemp1.getId().equals(F1)) {
				break;
			}
			f1++;
		}
		
		while(f2<flist.size()-1) {
			Ftemp2=flist.get(f2);
			if(Ftemp2.getId().equals(F2)) {
				break;
			}
			f2++;
		}
		
		while(p<plist.size()-1) {
			Ptemp=plist.get(p);
			if(Ptemp.getId().equals(i)) {
				break;
			}
			p++;
		}
		
		if(Ftemp1.getPassengerList().indexOf(Ptemp)>=0 && Ftemp2.getFreeSeats()>0 ) {
			Cancel(F1,i);
			Reserve(F2,i);
		}
	*/	
		
		
	}
	
	public void run() {
		switch(this.type) {
		case 1: 
			
		}
	}
}
